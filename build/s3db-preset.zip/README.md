Simple3dBuildingsPreset
=======================

Simple 3D Buildings Preset for JOSM. 


License
Icons created by me are on Public Domain license. 
Roof images come from http://wiki.openstreetmap.org are on wiki license.
